package com.edu.edu_planner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduPlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduPlannerApplication.class, args);
	}

}
