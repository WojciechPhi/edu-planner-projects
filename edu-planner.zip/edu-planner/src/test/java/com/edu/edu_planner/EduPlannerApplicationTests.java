package com.edu.edu_planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
